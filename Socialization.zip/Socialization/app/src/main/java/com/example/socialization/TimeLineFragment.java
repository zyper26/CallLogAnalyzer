package com.example.socialization;

import androidx.fragment.app.Fragment;

public class TimeLineFragment extends Fragment {

}
